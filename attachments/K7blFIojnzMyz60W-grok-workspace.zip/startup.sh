#!/bin/sh
set -eu
cd /workspace
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi
if [ ! -x /usr/local/bin/mvn ] && [ -x /opt/apache-maven-3.9.9/bin/mvn ]; then
  ln -sf /opt/apache-maven-3.9.9/bin/mvn /usr/local/bin/mvn
fi
cd /workspace/crsms
if [ ! -f target/crsms-1.0.0.jar ]; then
  mvn -q -DskipTests package
fi
export ADMIN_PASSWORD="${ADMIN_PASSWORD:-changeme}"
export SPRING_PROFILES_ACTIVE="${SPRING_PROFILES_ACTIVE:-dev}"
nohup java -jar target/crsms-1.0.0.jar > /tmp/crsms.log 2>&1 &
for i in $(seq 1 60); do
  if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
    exit 0
  fi
  sleep 1
done
echo "CRSMS did not start" >&2
tail -n 80 /tmp/crsms.log >&2 || true
exit 1
