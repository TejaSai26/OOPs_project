async function api(path, options = {}) {
  const opts = {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    ...options,
  };
  if (opts.body && typeof opts.body !== "string") {
    opts.body = JSON.stringify(opts.body);
  }
  const response = await fetch(path, opts);
  const text = await response.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch { data = { error: text }; }
  }
  if (!response.ok) {
    throw new Error((data && data.error) || response.statusText);
  }
  return data;
}

function toast(message, isError) {
  let el = document.querySelector(".toast");
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.style.display = "block";
  el.style.background = isError ? "#8d2f2f" : "#1c2430";
  el.textContent = message;
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.style.display = "none"; }, 4200);
}

function badge(status) {
  const bad = ["REJECTED", "CANCELLED", "DAMAGED", "LOST", "DEACTIVATED", "OVERDUE"];
  const ok = ["APPROVED", "ACTIVE", "AVAILABLE", "RETURNED", "RESOLVED", "GOOD", "NEW"];
  const cls = bad.includes(status) ? "bad" : ok.includes(status) ? "ok" : "warn";
  return `<span class="badge ${cls}">${status}</span>`;
}

async function mountNav() {
  const slot = document.querySelector("[data-nav]");
  if (!slot) return;
  let me = null;
  try { me = await api("/api/users/me"); } catch { me = null; }
  const links = [
    ["Home", "/index.html"],
    ["Browse", "/browse.html"],
  ];
  if (!me) {
    links.push(["Sign in", "/login.html"], ["Register", "/register.html"]);
  } else {
    links.push(
      ["Dashboard", "/dashboard.html"],
      ["My listings", "/my-listings.html"],
      ["Reservations", "/reservations.html"],
      ["Borrowings", "/borrowings.html"],
      ["Report damage", "/maintenance.html"]
    );
    if (me.role === "ADMIN") {
      links.push(["Admin", "/admin.html"], ["Users", "/admin-users.html"], ["Repairs", "/admin-maintenance.html"]);
    }
  }
  slot.innerHTML = links.map(([label, href]) => `<a href="${href}">${label}</a>`).join("")
    + (me ? `<button class="btn secondary" id="logout">Sign out</button>` : "");
  const side = document.querySelector("[data-side]");
  if (side && me) {
    side.innerHTML = links.slice(2).map(([label, href]) => {
      const active = location.pathname.endsWith(href) ? "active" : "";
      return `<a class="${active}" href="${href}">${label}</a>`;
    }).join("");
  }
  const btn = document.getElementById("logout");
  if (btn) {
    btn.onclick = async () => {
      await api("/api/auth/logout", { method: "POST" });
      location.href = "/login.html";
    };
  }
  return me;
}

function shell(title) {
  document.title = title + " · CRSMS";
}

document.addEventListener("DOMContentLoaded", () => { mountNav(); });
